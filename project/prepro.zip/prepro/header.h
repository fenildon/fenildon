#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void include_header(void);
void com_rmv(char *);
void macro(char *);

