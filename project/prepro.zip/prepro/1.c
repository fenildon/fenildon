#include<stdio.h>
#include<stdlib.h>
#define ab 123456

void main
{
int a=abc;/*asd*/
// asd
int b=0;//asd
/*asd
asd
*ddds
asd
*/
int c=0;
}
